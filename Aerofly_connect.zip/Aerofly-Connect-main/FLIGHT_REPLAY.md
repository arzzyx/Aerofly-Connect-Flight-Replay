# Flight Replay (additive feature)

This feature is added alongside the existing Pilot, Controller, and Settings flows.

## Included
- Flight Replay entry on the existing first screen on PC and Android.
- Automatic PC and Android recording while Pilot telemetry is running.
- Portable `aerofly-connect-replay` JSON files. Android can import a replay exported/copied from PC.
- 3D generic unpainted aircraft, altitude-aware 3D path, playback timeline, speed controls, Chase / Free / Top cameras.
- 2D OpenStreetMap raster scenery draped over a 3D terrain mesh. Terrain elevation is sampled from SRTM90m through OpenTopoData.

## Important telemetry note
The current Aerofly Connect data sources expose latitude, longitude, altitude, heading, ground speed and vertical speed. They do not consistently expose aircraft pitch/roll. Replay therefore stores a clearly named `pitchEstimateDeg` and `bankEstimateDeg` estimate where possible; it does not claim those estimates are exact simulator attitude data.

## Online map/elevation dependencies
The 3D viewer loads Three.js from jsDelivr, map tiles from OpenStreetMap, and elevation samples from OpenTopoData. Internet access is needed for those layers. If the elevation service is unavailable, the viewer falls back to a modest relief surface. OSM map tiles include attribution in the viewer.

## Data locations
- PC: Electron userData directory, `replays/`.
- Android: app-private files directory, `replays/`.
- To move a PC replay to Android, copy its `.json` file to the device and use **Import PC Replay (.json)**.
