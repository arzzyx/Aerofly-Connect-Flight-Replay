const { contextBridge, ipcRenderer } = require("electron");
contextBridge.exposeInMainWorld("replayApi", { read: file => ipcRenderer.invoke("replay:read", file) });
