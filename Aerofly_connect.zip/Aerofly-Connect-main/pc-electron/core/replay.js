// Additive flight recorder. Replay files are portable JSON and can be opened on PC or Android.
const fs = require('fs');
const path = require('path');

class ReplayRecorder {
  constructor(directory) { this.directory = directory; this.active = null; fs.mkdirSync(directory, { recursive: true }); }
  start(meta = {}) {
    if (this.active) return this.active.id;
    const id = new Date().toISOString().replace(/[:.]/g, '-');
    this.active = { schema: 'aerofly-connect-replay', version: 1, id, meta, startedAt: Date.now(), samples: [] };
    return id;
  }
  add(position, meta = {}) {
    if (!this.active || !position) return;
    const n = (v, d = null) => Number.isFinite(Number(v)) ? Number(v) : d;
    const prev = this.active.samples[this.active.samples.length - 1];
    const now = Date.now();
    let bank = null;
    if (prev) { let d = n(position.heading_true, 0) - n(prev.heading, 0); while (d > 180) d -= 360; while (d < -180) d += 360; bank = Math.max(-35, Math.min(35, d * 2.2)); }
    this.active.samples.push({ t: now, lat: n(position.latitude), lon: n(position.longitude), altitudeFt: n(position.altitude_ft, 0), heading: n(position.heading_true, 0), groundSpeedKt: n(position.ground_speed, 0), verticalSpeedFpm: n(position.vertical_speed_ft_min, 0), bankEstimateDeg: bank, pitchEstimateDeg: Math.max(-12, Math.min(18, n(position.vertical_speed_ft_min, 0) / 250)), ...meta });
  }
  stop(meta = {}) {
    if (!this.active) return null;
    const r = this.active; this.active = null; r.endedAt = Date.now(); r.meta = { ...r.meta, ...meta };
    if (r.samples.length) { const file = path.join(this.directory, r.id + '.json'); fs.writeFileSync(file, JSON.stringify(r)); return file; }
    return null;
  }
  list() {
    return fs.readdirSync(this.directory).filter(x => x.endsWith('.json')).map(name => {
      try { const r = JSON.parse(fs.readFileSync(path.join(this.directory, name), 'utf8')); return { id: r.id, name: r.meta.callsign || r.meta.departure && r.meta.arrival ? `${r.meta.callsign || 'Flight'} · ${r.meta.departure || ''} → ${r.meta.arrival || ''}` : r.id, date: r.startedAt, samples: (r.samples || []).length, file: name }; } catch (_) { return null; }
    }).filter(Boolean).sort((a,b) => b.date-a.date);
  }
  read(file) { if (!/^[\w.-]+\.json$/.test(file)) throw new Error('Invalid replay filename'); return JSON.parse(fs.readFileSync(path.join(this.directory, file), 'utf8')); }
}
module.exports = { ReplayRecorder };
